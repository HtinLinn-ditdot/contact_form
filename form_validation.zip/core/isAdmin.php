<?php

if($_SESSION["user"]["role"]!= 0){
    linkTo("dashboard.php");
}